package bangkit.android.intermediate.viewmodel

import DataStoreManager
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.paging.PagingSource
import androidx.paging.PagingState
import androidx.recyclerview.widget.ListUpdateCallback
import bangkit.android.intermediate.DummyData
import bangkit.android.intermediate.MainDispatcherRule
import bangkit.android.intermediate.adapter.PagingAdapter
import bangkit.android.intermediate.feedback.ListStoryItem
import bangkit.android.intermediate.getOrAwaitValue
import bangkit.android.intermediate.repo.StoryRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class MyViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val mainDispatcherRules = MainDispatcherRule()

    @Mock
    private lateinit var dataStoreManager: DataStoreManager

    @Mock
    private lateinit var storyRepository: StoryRepo

    private val dummyStories = DummyData.generateDummyStoryResponse()
    private val dummyToken =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJ1c2VyLUc2ME05ZldDNE1Rbm9JQk4iLCJpYXQiOjE2OTg4Njc0Mjd9.iPtHNkp94G05bcwF6l7C8sOnpRSfgibI_8apM-HnMy0"

    @Test
    fun `When Story Should not Null and Return Data`() = runTest {

        val data: PagingData<ListStoryItem> = StoryPagingSource.snapshot(dummyStories)
        val expectedStory = MutableLiveData<PagingData<ListStoryItem>>()
        expectedStory.value = data
        Mockito.`when`(storyRepository.fetchStories()).thenReturn(expectedStory)

        val myViewModel = MyViewModel(storyRepository, dataStoreManager)
        myViewModel.authToken.value = dummyToken
        val actualStory: PagingData<ListStoryItem> = myViewModel.stories.getOrAwaitValue()

        val differ = AsyncPagingDataDiffer(
            diffCallback = PagingAdapter.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main,
        )

        differ.submitData(actualStory)
        assertNotNull(differ.snapshot())
        assertEquals(dummyStories.size, differ.snapshot().size)
        assertEquals(dummyStories[0], differ.snapshot()[0])
    }

    @Test
    fun `when Get Story Empty Should Return No Data`() = runTest {

        val data: PagingData<ListStoryItem> = PagingData.from(emptyList())
        val expectedStory = MutableLiveData<PagingData<ListStoryItem>>()
        expectedStory.value = data
        Mockito.`when`(storyRepository.fetchStories()).thenReturn(expectedStory)

        val myViewModel = MyViewModel(storyRepository, dataStoreManager)
        myViewModel.authToken.value = dummyToken
        val actualStory: PagingData<ListStoryItem> = myViewModel.stories.getOrAwaitValue()

        val differ = AsyncPagingDataDiffer(
            diffCallback = PagingAdapter.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main,
        )
        differ.submitData(actualStory)
        assertEquals(0, differ.snapshot().size)
    }

}

class StoryPagingSource : PagingSource<Int, LiveData<List<ListStoryItem>>>() {
    override fun getRefreshKey(state: PagingState<Int, LiveData<List<ListStoryItem>>>): Int? {
        return 0
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, LiveData<List<ListStoryItem>>> {
        return LoadResult.Page(emptyList(), 0, 1)
    }


    companion object {
        fun snapshot(items: List<ListStoryItem>): PagingData<ListStoryItem> {
            return PagingData.from(items)
        }
    }
}

val noopListUpdateCallback = object : ListUpdateCallback {
    override fun onInserted(position: Int, count: Int) {}

    override fun onChanged(position: Int, count: Int, payload: Any?) {}

    override fun onMoved(fromPosition: Int, toPosition: Int) {}

    override fun onRemoved(position: Int, count: Int) {}


}


