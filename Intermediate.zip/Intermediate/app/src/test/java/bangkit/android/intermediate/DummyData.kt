package bangkit.android.intermediate

import bangkit.android.intermediate.feedback.ListStoryItem


object DummyData {
    fun generateDummyStoryResponse(): List<ListStoryItem> {
        val items: MutableList<ListStoryItem> = arrayListOf()
        for(i in 0..100) {
            val stories = ListStoryItem(
                "https://story-api.dicoding.dev/images/stories/photos-1683035377773_BPKaDWeA.jpg",
                "2023-05-02T13:49:37.774Z",
                "Budi",
                "test description",
                -7.7794882,
                "story-NyGJQv7oYd59DC-U",
                110.3909943,
            )
            items.add(stories)
        }
        return items
    }

}