package bangkit.android.intermediate.viewmodel

import DataStoreManager
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import bangkit.android.intermediate.api.Retrofit
import bangkit.android.intermediate.repo.LocalRepo
import bangkit.android.intermediate.repo.StoryRepo
import bangkit.android.intermediate.feedback.FeedbackError
import bangkit.android.intermediate.feedback.ListStoryItem
import bangkit.android.intermediate.feedback.LoginResponse
import bangkit.android.intermediate.feedback.FeedbackRegister
import bangkit.android.intermediate.feedback.StoryResponse
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.File

class MyViewModel(private val storyRepo: StoryRepo, private val dataStoreManager: DataStoreManager) : ViewModel() {

    val authToken: MutableLiveData<String> = MutableLiveData()
    fun getToken() = viewModelScope.launch{
        dataStoreManager.getAuthTokenFlow().collect{
            authToken.value = it
        }
    }
    private val repository = LocalRepo(authToken.value.toString())


    private val errorMessageLiveData = MutableLiveData<String>()
    val errorMessage: LiveData<String>
        get() = errorMessageLiveData

    private val errorLiveData = MutableLiveData<Boolean>()
    val error: LiveData<Boolean>
        get() = errorLiveData



    val stories: LiveData<PagingData<ListStoryItem>> =
        storyRepo.fetchStories().cachedIn(viewModelScope)

    private val loginResponseLiveData = MutableLiveData<LoginResponse>()
    val loginResponse: LiveData<LoginResponse>
        get() = loginResponseLiveData

    private val loadingLiveData = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean>
        get() = loadingLiveData

    private val uploadStoryResultLiveData = MutableLiveData<Result<StoryResponse>>()
    val uploadStoryResult: LiveData<Result<StoryResponse>>
        get() = uploadStoryResultLiveData


    fun saveAuthToken(token: String) {
        viewModelScope.launch {
            dataStoreManager.saveAuthToken(token)
        }
    }

    fun getThemeSettings(): LiveData<Boolean> {
        return dataStoreManager.getThemeSetting().asLiveData()
    }

    fun saveThemeSetting(isDarkModeActive: Boolean) {
        viewModelScope.launch {
            dataStoreManager.saveThemeSetting(isDarkModeActive)
        }
    }

    fun getStorieswithToken(location: Int): LiveData<List<ListStoryItem>> {
        return liveData(Dispatchers.IO) {
            try {
                val response = storyRepo.fetchStorieswithLocation( location)
                emit(response.listStory)
            } catch (e: HttpException) {
                val jsonInString = e.response()?.errorBody()?.string()
                val errorBody = Gson().fromJson(jsonInString, FeedbackError::class.java)
                val errorMessage = errorBody.message.toString()
                errorMessageLiveData.postValue(errorMessage)
            }
        }
    }


    fun register(name: String, email: String, password: String): LiveData<FeedbackRegister> {
        val result = MutableLiveData<FeedbackRegister>()
        loadingLiveData.postValue(true)
        viewModelScope.launch {
            try {
                val response = repository.register(name, email, password)
                result.postValue(response)
            } catch (e: HttpException) {
                val jsonInString = e.response()?.errorBody()?.string()
                val errorBody = Gson().fromJson(jsonInString, FeedbackError::class.java)
                val errorMessage = errorBody.message.toString()
                errorMessageLiveData.postValue(errorMessage)

            } finally {
                loadingLiveData.postValue(false)
            }
        }
        return result
    }

    fun login(email: String, password: String) {
        loadingLiveData.postValue(true)
        viewModelScope.launch {
            try {
                val response = repository.login(email, password)
                loginResponseLiveData.postValue(response)
                if (response.loginResult != null) {
                    val token = response.loginResult.token
                    if (token != null) {
                        dataStoreManager.saveAuthToken(token)
                    }
                }
            } catch (e: HttpException) {
                val jsonInString = e.response()?.errorBody()?.string()
                val errorBody = Gson().fromJson(jsonInString, FeedbackError::class.java)
                val errorMessage = errorBody.message.toString()
                errorMessageLiveData.postValue(errorMessage)
            } finally {
                loadingLiveData.postValue(false)
            }
        }
    }

    suspend fun uploadStory(photoUri: File, description: String, lat: Float, lon: Float) {

        loadingLiveData.postValue(true)
        try {
            val photoFile = File(photoUri.path)
            val token = dataStoreManager.getAuthTokenFlow().first().toString()

            val response = storyRepo.uploadStory(token, description, photoFile, lat, lon)
            uploadStoryResultLiveData.postValue(Result.success(response))

        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, FeedbackError::class.java)
            val errorMessage = errorBody.message.toString()
            errorMessageLiveData.postValue(errorMessage)
        } finally {
            loadingLiveData.postValue(false)
        }
    }

}