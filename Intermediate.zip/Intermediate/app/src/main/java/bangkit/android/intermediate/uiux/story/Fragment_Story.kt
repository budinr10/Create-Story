package bangkit.android.intermediate.uiux.story

import DataStoreManager
import android.Manifest
import bangkit.android.intermediate.viewmodel.MyViewModelFactory
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import bangkit.android.intermediate.Injection
import bangkit.android.intermediate.MainActivity
import bangkit.android.intermediate.databinding.StoryFragmentBinding
import bangkit.android.intermediate.viewmodel.MyViewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import dataStore
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException


class Fragment_Story : Fragment() {
    private var _binding: StoryFragmentBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: MyViewModel
    private lateinit var fusedLocationClient: FusedLocationProviderClient


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = StoryFragmentBinding.inflate(inflater, container, false)

        val dataStoreManager = DataStoreManager.getInstance(requireActivity().application.dataStore)
        val viewModelFactory = MyViewModelFactory(Injection.provideRepository(dataStoreManager), dataStoreManager)
        viewModel = ViewModelProvider(this, viewModelFactory)[MyViewModel::class.java]
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())


        val imageUriString = arguments?.getString("imageUri")
        val capturedImage = arguments?.getParcelable<Bitmap>("capturedImage")

        if (imageUriString != null) {
            val imageUri = Uri.parse(imageUriString)
            binding.imageView.setImageURI(imageUri)
        } else if (capturedImage != null) {
            binding.imageView.setImageBitmap(capturedImage)
        }

        binding.sendButton.setOnClickListener {
            if (binding.descriptionEd.text.isEmpty()) {
                binding.descriptionEd.setError("Description cannot be empty!")
            } else {
                uploadStory()
            }
        }

        return binding.root
    }


    private fun uploadStory() {
        val description = binding.descriptionEd.text.toString()
        val imageUriString = arguments?.getString("imageUri")
        val capturedImage = arguments?.getParcelable<Bitmap>("capturedImage")

        // Periksa izin lokasi
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        val lat = location.latitude
                        val lon = location.longitude

                        if (imageUriString != null) {
                            val imageView = binding.imageView
                            imageView.isDrawingCacheEnabled = true
                            imageView.buildDrawingCache()
                            val bitmap = imageView.drawingCache
                            val imageFile = saveBitmaptoFile(bitmap)

                            if (imageFile != null) {
                                uploadStoryWithImageFile(imageFile, description, lat.toFloat(), lon.toFloat())
                            }
                        } else if (capturedImage != null) {
                            val imageFile = saveBitmaptoFile(capturedImage)

                            if (imageFile != null) {
                                uploadStoryWithImageFile(imageFile, description, lat.toFloat(), lon.toFloat())
                            }
                        }
                    } else {
                        Toast.makeText(
                            requireContext(),
                            "Failed to get location",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        } else {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_LOCATION_PERMISSION
            )
        }
    }

    private fun uploadStoryWithImageFile(imageFile: File, description: String, lat:Float, lon: Float) {
        lifecycleScope.launch {
            viewModel.uploadStory(imageFile, description, lat, lon)
            Toast.makeText(
                requireContext(),
                "Story Upload Successful",
                Toast.LENGTH_SHORT
            ).show()

            val intent = Intent(requireActivity(), MainActivity::class.java)
            intent.flags =
                Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            requireActivity().finish()

        }
        viewModel.errorMessage.observe(viewLifecycleOwner, Observer { errorMessage ->
            if (!errorMessage.isNullOrBlank()) {
                Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()
            }
        })

        viewModel.loading.observe(viewLifecycleOwner, Observer { isLoading ->
            if (isLoading) {
                binding.progressBar.visibility = View.VISIBLE
                binding.sendButton.visibility = View.GONE
            } else {
                binding.sendButton.visibility = View.VISIBLE
                binding.progressBar.visibility = View.GONE
            }
        })



    }


    private fun saveBitmaptoFile(bitmap: Bitmap?): File? {

        val filesDir = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val imageFile = File(filesDir, "uploaded_image.png")

        return try {
            val fos = FileOutputStream(imageFile)
            bitmap?.compress(Bitmap.CompressFormat.JPEG, 100, fos)
            fos.flush()
            fos.close()
            imageFile
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val REQUEST_LOCATION_PERMISSION = 123
    }


}