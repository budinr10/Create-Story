package bangkit.android.intermediate

import DataStoreManager
import bangkit.android.intermediate.repo.StoryRepo
import bangkit.android.intermediate.api.Retrofit
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Injection {
    fun provideRepository(dataStoreManager: DataStoreManager): StoryRepo {

        val authTokenFlow = dataStoreManager.getAuthTokenFlow()
        val authToken = runBlocking { authTokenFlow.first() }
        val apiService = Retrofit.getApiService(authToken.toString())


        return StoryRepo(apiService, dataStoreManager)
    }
}



