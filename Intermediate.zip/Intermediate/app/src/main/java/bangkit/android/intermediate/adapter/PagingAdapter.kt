package bangkit.android.intermediate.adapter

import android.content.Context
import android.content.Intent
import android.location.Geocoder
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import bangkit.android.intermediate.R
import bangkit.android.intermediate.databinding.CardstoryBinding
import bangkit.android.intermediate.feedback.ListStoryItem
import bangkit.android.intermediate.uiux.DetailActivity

import com.bumptech.glide.Glide
import com.google.android.gms.maps.model.LatLng
import java.util.Locale


class PagingAdapter : PagingDataAdapter<ListStoryItem, PagingAdapter.MyViewHolder>(
    DIFF_CALLBACK
) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = CardstoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }


     class MyViewHolder(private val binding: CardstoryBinding) : RecyclerView.ViewHolder(binding.root) {
         private var itemClickListener : OnItemClickListener? = null

         interface OnItemClickListener {
             fun onItemClick(data: ListStoryItem)
         }

         fun bind(data: ListStoryItem, context: Context) {
            binding.namePhoto.text = data.name
            binding.descPhoto.text = data.description
            Glide.with(context)
                .load(data.photoUrl)
                .into(binding.postPhoto)

             val latLng = LatLng(data.lat, data.lon)
             val geocoder = Geocoder(context, Locale.getDefault())
             val addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)

             if (addresses!!.isNotEmpty()) {
                 val city = addresses[0].locality
                 val state = addresses[0].adminArea

                 binding.location.text = context.getString(R.string.latlong, city,",\n$state")
             } else {
                 binding.location.visibility = View.GONE
             }

            binding.root.setOnClickListener {
                itemClickListener?.onItemClick(data)
                val bundle = Bundle()

                bundle.putString("name", data.name)
                bundle.putString("desc", data.description)
                bundle.putString("photo", data.photoUrl)

                val intent = Intent(context, DetailActivity::class.java)
                intent.putExtras(bundle)
                context.startActivity(intent)
            }
        }
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = getItem(position)
        item?.let {
            holder.bind(it, holder.itemView.context)
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListStoryItem>() {
            override fun areItemsTheSame(oldItem: ListStoryItem, newItem: ListStoryItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: ListStoryItem, newItem: ListStoryItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}
