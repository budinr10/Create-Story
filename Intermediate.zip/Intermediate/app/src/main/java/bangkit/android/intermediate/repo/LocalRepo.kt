    package bangkit.android.intermediate.repo

    import bangkit.android.intermediate.api.Retrofit
    import bangkit.android.intermediate.feedback.LoginResponse
    import bangkit.android.intermediate.feedback.FeedbackRegister

    class LocalRepo(authToken: String) {
        private val apiService = Retrofit.getApiService(authToken)

        suspend fun register(name: String, email: String, password: String): FeedbackRegister {
            return apiService.register(name, email, password)
        }

        suspend fun login(email: String, password: String): LoginResponse {
            return apiService.login(email, password)
        }


    }
