package bangkit.android.intermediate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import bangkit.android.intermediate.uiux.setting.Fragment_Setting
import bangkit.android.intermediate.viewmodel.MyViewModel
import bangkit.android.intermediate.viewmodel.MyViewModelFactory
import bangkit.android.intermediate.uiux.home.Fragment_Home
import bangkit.android.intermediate.uiux.story.Fragment_Story
import com.google.android.material.bottomnavigation.BottomNavigationView
import dataStore

class MainActivity : AppCompatActivity() {

    private val IMAGEPICKERREQUEST = 1
    private val CAMERACAPTUREREQUEST = 2
    private lateinit var viewModel : MyViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val dataStoreManager = DataStoreManager.getInstance(application.dataStore)
        val viewModelFactory = MyViewModelFactory(Injection.provideRepository(dataStoreManager), dataStoreManager)
        viewModel = ViewModelProvider(this, viewModelFactory)[MyViewModel::class.java]

        setUpTheme()

        val bottomNav: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_home -> {
                    loadFragment(Fragment_Home())
                    return@setOnItemSelectedListener true
                }

                R.id.menu_add -> {
                    showImagePickerDialog()
                    return@setOnItemSelectedListener true
                }

                R.id.menu_setting -> {
                    loadFragment(Fragment_Setting())
                    return@setOnItemSelectedListener true
                }

                else -> false
            }
        }
        loadFragment(Fragment_Home())
    }

    private fun setUpTheme() {
        viewModel.getThemeSettings().observe(this) {isDarkModeActive: Boolean ->
            if(isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

        }

    }

    private fun showImagePickerDialog() {
        val options = arrayOf("Gallery", "Camera")
        val builder = AlertDialog.Builder(this)
        builder.setTitle(R.string.selectsource)
        builder.setItems(options) { dialog, which ->
            when (which) {
                0 -> {
                    requestGalleryPermissionAndPickImage()
                }

                1 -> {
                    requestCameraPermissionAndCaptureImage()
                }
            }
            dialog.dismiss()
        }
        builder.setOnCancelListener{
            val bottomNav: BottomNavigationView = findViewById(R.id.bottom_navigation)
            bottomNav.selectedItemId = R.id.menu_home
        }
        builder.show()
    }

    private fun requestGalleryPermissionAndPickImage() {
        val galleryPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(
                this,
                galleryPermission
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startGalleryImagePicker()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(galleryPermission),
                IMAGEPICKERREQUEST
            )
        }
    }

    private fun requestCameraPermissionAndCaptureImage() {
        val cameraPermission = Manifest.permission.CAMERA
        if (ContextCompat.checkSelfPermission(
                this,
                cameraPermission
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startCameraCapture()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(cameraPermission),
                CAMERACAPTUREREQUEST
            )
        }
    }

    private fun startGalleryImagePicker() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, IMAGEPICKERREQUEST)
    }

    private fun startCameraCapture() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, CAMERACAPTUREREQUEST)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            IMAGEPICKERREQUEST -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startGalleryImagePicker()
                }
            }

            CAMERACAPTUREREQUEST -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startCameraCapture()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                IMAGEPICKERREQUEST -> {
                    val selectedImage: Uri? = data?.data
                    val fragmentStory = Fragment_Story()
                    val bundle = Bundle()
                    bundle.putString("imageUri", selectedImage.toString())
                    fragmentStory.arguments = bundle
                    loadFragment(fragmentStory)

                }

                CAMERACAPTUREREQUEST -> {
                    val capturedImage = data?.extras?.get("data") as Bitmap?
                    if (capturedImage != null) {
                        val fragmentStory = Fragment_Story()
                        val bundle = Bundle()
                        bundle.putParcelable("capturedImage", capturedImage)
                        fragmentStory.arguments = bundle
                        loadFragment(fragmentStory)
                    } else {
                        Toast.makeText(this, "Failed to Obtain Image" , Toast.LENGTH_SHORT).show()
                        val bottomNav: BottomNavigationView = findViewById(R.id.bottom_navigation)
                        bottomNav.selectedItemId = R.id.menu_home
                    }
                }
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()
        val currentFragment = fragmentManager.findFragmentById(R.id.fragment_container)

        if (currentFragment != null) {
            transaction.remove(currentFragment)
        }
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

}