package bangkit.android.intermediate.adapter

import android.graphics.Color
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.paging.LoadState
import androidx.paging.LoadStateAdapter
import androidx.recyclerview.widget.RecyclerView
import bangkit.android.intermediate.databinding.ItemLoadingBinding


class LoadAdapter(private val retry:() -> Unit) :
    LoadStateAdapter<LoadAdapter.LoadingStateViewHolder>() {

    class LoadingStateViewHolder(private val binding : ItemLoadingBinding, retry: () -> Unit): RecyclerView.ViewHolder(binding.root) {

        fun bind(loadState: LoadState) {
            if(loadState is LoadState.Error) {
                binding.errorMsg.text = loadState.error.localizedMessage
            }
            binding.progressBar.isVisible = loadState is LoadState.Loading
            binding.errorMsg.isVisible = loadState is LoadState.Error

        }

        init {
            val errorMsgTextView = binding.errorMsg

            val text = "Error, Try Again"
            val spannableString = SpannableString(text)

            val clickableSpan = object: ClickableSpan(){
                override fun onClick(widget: View) {
                    retry.invoke()
                }

                override fun updateDrawState(ds: TextPaint) {
                    super.updateDrawState(ds)
                    ds.isUnderlineText = true
                }
            }

            val startIndex = text.indexOf("Try Again")
            spannableString.setSpan(clickableSpan, startIndex, startIndex + 9, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

            errorMsgTextView.text = spannableString
            errorMsgTextView.movementMethod = LinkMovementMethod.getInstance()
            errorMsgTextView.highlightColor = Color.CYAN

        }

    }

    override fun onBindViewHolder(holder: LoadingStateViewHolder, loadState: LoadState) {
        holder.bind(loadState)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        loadState: LoadState
    ): LoadingStateViewHolder {
        val binding = ItemLoadingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LoadingStateViewHolder(binding, retry)
    }
}