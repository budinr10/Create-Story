import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_prefs")

class DataStoreManager private constructor(private val dataStore: DataStore<Preferences>) {
    private val authTokenKey = stringPreferencesKey("auth_token")
    private val userNameKey = stringPreferencesKey("user_name")
    private val userEmailKey = stringPreferencesKey("user_email")
    private val themeKey = booleanPreferencesKey("theme_setting")

    fun getThemeSetting(): Flow<Boolean> {
        return dataStore.data.map { preferences ->
            preferences[themeKey] ?: false
        }
    }

    suspend fun saveThemeSetting(isDarkModeActive: Boolean) {
        dataStore.edit { preferences ->
            preferences[themeKey] = isDarkModeActive
        }
    }

    suspend fun saveAuthToken(token: String) {
        dataStore.edit { preferences ->
            preferences[authTokenKey] = token
        }
    }

    fun getAuthTokenFlow(): Flow<String> = dataStore.data.map { preferences ->
        preferences[authTokenKey] ?: ""
    }

    suspend fun saveUserData(name: String, email: String) {
        dataStore.edit { preferences ->
            preferences[userNameKey] = name
            preferences[userEmailKey] = email
        }
    }

    suspend fun clearUserData() {
        dataStore.edit {
            preferences ->
            preferences.remove(authTokenKey)
            preferences.remove(userNameKey)
            preferences.remove(userEmailKey)
        }
    }

    suspend fun isLoggedIn(): Boolean {
        val authTokenFlow = dataStore.data.map { preferences ->
            preferences[authTokenKey] ?: ""
        }
        val authToken = authTokenFlow.first()
        return authToken.isNotEmpty()
    }

    suspend fun getUsername(): String {
        val dataStore = dataStore
        val preferences = dataStore.data.first()
        return preferences[userNameKey] ?: ""
    }

    companion object {
        private var INSTANCE: DataStoreManager? = null

        fun getInstance(dataStore: DataStore<Preferences>): DataStoreManager{
            return INSTANCE ?: synchronized(this) {
                val instance = DataStoreManager(dataStore)
                INSTANCE = instance
                instance
            }
        }
    }

}
