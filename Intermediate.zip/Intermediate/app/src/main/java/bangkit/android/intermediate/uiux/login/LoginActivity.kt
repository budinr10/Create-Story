package bangkit.android.intermediate.uiux.login

import DataStoreManager
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import bangkit.android.intermediate.Injection
import bangkit.android.intermediate.MainActivity
import bangkit.android.intermediate.R
import bangkit.android.intermediate.databinding.ActivityLoginBinding
import bangkit.android.intermediate.uiux.signup.SignupActivity
import bangkit.android.intermediate.viewmodel.MyViewModel
import bangkit.android.intermediate.viewmodel.MyViewModelFactory
import dataStore
import kotlinx.coroutines.launch


class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var viewModel: MyViewModel
    private lateinit var dataStore: DataStoreManager
    private var token: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        dataStore = DataStoreManager.getInstance(application.dataStore)
        viewModel = ViewModelProvider(this, MyViewModelFactory(Injection.provideRepository(dataStore), dataStore))[MyViewModel::class.java]
        playAnimation()

        lifecycleScope.launch{
            val isLoggedIn = dataStore.isLoggedIn()
            val username = dataStore.getUsername()
            val welcome = getString(R.string.welcomeback, username)
            if (isLoggedIn) {
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                Toast.makeText(this@LoginActivity, welcome, Toast.LENGTH_SHORT).show()
                finish()
            } else {

            }
        }

        binding.apply {

            binding.buttonLogin.setButtonText("LOGIN")

            registerNow.setOnClickListener {
                registerActivity()
            }

            buttonLogin.setOnClickListener {
                val email = emailEd.text.toString()
                val password = passwordEd.text.toString()
                viewModel.login(email, password)

                observeLoginResponse()
            }
        }
    }

    private fun observeLoginResponse() {
        viewModel.loginResponse.observe(this, Observer { loginResponse ->
            if (loginResponse != null && loginResponse.loginResult != null) {
                token = loginResponse.loginResult.token ?: ""
                viewModel.saveAuthToken(token)

                lifecycleScope.launch {
                    val username = loginResponse.loginResult.name ?: ""
                    val email = binding.emailEd.text.toString()
                    dataStore.saveUserData(username, email)
                }

                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()

                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        })

        viewModel.errorMessage.observe(this, Observer { errorMessage ->
            if (!errorMessage.isNullOrBlank()) {
                Toast.makeText(applicationContext, errorMessage, Toast.LENGTH_SHORT).show()
            }
        })

        viewModel.loading.observe(this, Observer { isLoading ->
            if(isLoading){
                binding.buttonLogin.startLoading()
                binding.buttonLogin.isEnabled = false
            } else {
                binding.buttonLogin.stopLoading()
                binding.buttonLogin.isEnabled = true
            }
        })
    }

    private fun registerActivity() {
        val intent = Intent(this@LoginActivity, SignupActivity::class.java)
        startActivity(intent)

    }

    private fun playAnimation() {
        val helloText = ObjectAnimator.ofFloat(binding.welcome, View.ALPHA, 1f).setDuration(600)
        val logincontinueText = ObjectAnimator.ofFloat(binding.textLogin, View.ALPHA, 1f).setDuration(600)
        val loginEd = ObjectAnimator.ofFloat(binding.emailinputLayout, View.ALPHA, 1f).setDuration(600)
        val passwordEd = ObjectAnimator.ofFloat(binding.passwordInputLayout, View.ALPHA, 1f).setDuration(600)
        val buttonLogin = ObjectAnimator.ofFloat(binding.buttonLogin, View.ALPHA, 1f).setDuration(600)

        AnimatorSet().apply {
            playSequentially(helloText, logincontinueText, loginEd, passwordEd, buttonLogin)
            start()
        }

    }
}