package bangkit.android.intermediate.uiux.setting

import DataStoreManager
import bangkit.android.intermediate.viewmodel.MyViewModelFactory
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import bangkit.android.intermediate.Injection
import bangkit.android.intermediate.R
import bangkit.android.intermediate.databinding.SettingFragmentBinding
import bangkit.android.intermediate.viewmodel.MyViewModel
import bangkit.android.intermediate.uiux.home.Fragment_Home
import bangkit.android.intermediate.uiux.login.LoginActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import dataStore
import kotlinx.coroutines.launch

class Fragment_Setting : Fragment() {
    private var _binding : SettingFragmentBinding? = null
    private val binding get() = _binding!!
    private lateinit var dataStore: DataStoreManager



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = SettingFragmentBinding.inflate(inflater, container, false)

        dataStore = DataStoreManager.getInstance(requireActivity().application.dataStore)
        val viewModel = ViewModelProvider(this, MyViewModelFactory(Injection.provideRepository(dataStore), dataStore))[MyViewModel::class.java]

        viewModel.getThemeSettings().observe(viewLifecycleOwner) {isDarkModeActive: Boolean ->
            if(isDarkModeActive){
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                binding.nightSwitch.isChecked = true
            } else{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                binding.nightSwitch.isChecked = false
            }
        }

        binding.nightSwitch.setOnCheckedChangeListener{_: CompoundButton?, isChecked: Boolean ->
            viewModel.saveThemeSetting(isChecked)
        }

        binding.nightSwitch.setOnClickListener {
            val fragmentManager = requireActivity().supportFragmentManager
            fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, Fragment_Home())
                .addToBackStack(null)
                .commit()

            val bottomNavigationView = requireActivity().findViewById<BottomNavigationView>(R.id.bottom_navigation)
            bottomNavigationView.selectedItemId = R.id.menu_home
        }

        setupLanguage()
        setupLogout()

        return binding.root
    }

    private fun setupLogout() {
        binding.logout.setOnClickListener{
            clearUserData()
        }
    }

    private fun clearUserData() {
        lifecycleScope.launch {
            dataStore.clearUserData()
            navigatetoLoginScreen()
        }
    }

    private fun navigatetoLoginScreen() {
        val intent = Intent(requireActivity(), LoginActivity::class.java)
        intent.flags =
            Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        requireActivity().finish()
    }


    private fun setupLanguage() {
        binding.language.setOnClickListener{
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
        }
    }

}