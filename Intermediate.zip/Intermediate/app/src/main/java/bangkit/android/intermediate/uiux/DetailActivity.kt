package bangkit.android.intermediate.uiux

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import bangkit.android.intermediate.databinding.ActivityDetailBinding
import com.bumptech.glide.Glide

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val intent = getIntent()
        val getName = intent.getStringExtra("name")
        val getDescription = intent.getStringExtra("desc")
        val getPhoto = intent.getStringExtra("photo")

        binding.apply {
            name.text = getName
            topName.text = getName
            description.text = getDescription
            Glide.with(this@DetailActivity)
                .load(getPhoto)
                .into(imageView)
            back.setOnClickListener {
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

}