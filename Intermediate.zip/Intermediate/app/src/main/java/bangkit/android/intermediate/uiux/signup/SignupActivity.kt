package bangkit.android.intermediate.uiux.signup

import DataStoreManager
import bangkit.android.intermediate.viewmodel.MyViewModelFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import bangkit.android.intermediate.Injection
import bangkit.android.intermediate.R
import bangkit.android.intermediate.databinding.ActivitySignupBinding
import bangkit.android.intermediate.viewmodel.MyViewModel
import dataStore

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var viewModel: MyViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary)
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)


        val dataStore = DataStoreManager.getInstance(application.dataStore)
        viewModel = ViewModelProvider(this, MyViewModelFactory(Injection.provideRepository(dataStore), dataStore))[MyViewModel::class.java]

        binding.apply {

            loginNow.setOnClickListener {
                finish()
            }

            buttonRegister.setOnClickListener {
                if (passwordEd.length() < 8) {
                    passwordEd.error = "Password atleast must be 8 Character Long"
                } else {
                    passwordEd.error = null

                    val name = nameEd.text.toString()
                    val email = emailEd.text.toString()
                    val password = passwordEd.text.toString()
                    viewModel.register(name, email, password)
                        .observe(this@SignupActivity) { response ->
                            if (response != null) {
                                Toast.makeText(
                                    applicationContext,
                                    "Register Successful",
                                    Toast.LENGTH_SHORT
                                ).show()
                                finish()
                            }
                        }

                    viewModel.errorMessage.observe(this@SignupActivity) { errorMessage ->
                        if (!errorMessage.isNullOrBlank()) {
                            Toast.makeText(applicationContext, errorMessage, Toast.LENGTH_SHORT)
                                .show()
                        }
                    }
                }
            }

            viewModel.loading.observe(this@SignupActivity) { isLoading ->
                if(isLoading){
                    binding.buttonRegister.startLoading()
                    binding.buttonRegister.isEnabled = false
                } else {
                    binding.buttonRegister.stopLoading()
                    binding.buttonRegister.isEnabled = true
                }
            }

        }
    }
}