package bangkit.android.intermediate.uiux.maps

import DataStoreManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.content.res.Resources
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import bangkit.android.intermediate.Injection
import bangkit.android.intermediate.R
import bangkit.android.intermediate.databinding.ActivityMapsBinding
import bangkit.android.intermediate.feedback.ListStoryItem
import bangkit.android.intermediate.viewmodel.MyViewModel
import bangkit.android.intermediate.viewmodel.MyViewModelFactory

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import bangkit.android.intermediate.uiux.DetailActivity
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MapStyleOptions
import dataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var dataStore: DataStoreManager
    private lateinit var viewModel: MyViewModel
    private val boundsBuilder = LatLngBounds.Builder()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)


        dataStore = DataStoreManager.getInstance(application.dataStore)
        viewModel = ViewModelProvider(this, MyViewModelFactory(Injection.provideRepository(dataStore), dataStore))[MyViewModel::class.java]


        binding.back.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private val permissionRequestLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }


    private fun getMyLocation() {

        if (ContextCompat.checkSelfPermission(
                this.applicationContext, android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            permissionRequestLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun setMapStyle() {
        val isNightMode =
            when (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
                Configuration.UI_MODE_NIGHT_YES -> true
                else -> false
            }

        val mapStyle = if (isNightMode) {
            R.raw.map_style_night
        } else {
            R.raw.map_style_light
        }

        try {
            val success =
                mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, mapStyle))
            if (!success) {
                Toast.makeText(this, "Style Parsing Failed", Toast.LENGTH_SHORT).show()
            }
        } catch (exception: Resources.NotFoundException) {
            Toast.makeText(this, "Style Not Found", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        getMyLocation()
        setMapStyle()
        getStories()

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true
    }

    private fun getStories() {

        lifecycleScope.launch {
            val token = dataStore.getAuthTokenFlow().first().toString()
            val location = 1

            viewModel.getStorieswithToken(location)
                .observe(this@MapsActivity) { storyResponse ->

                    storyResponse.forEach { data ->
                        val latLng = LatLng(data.lat, data.lon)
                        val marker = mMap.addMarker(
                            MarkerOptions()
                                .position(latLng)
                                .title(data.name)
                                .snippet(data.description)
                        )
                        boundsBuilder.include(latLng)
                        marker?.tag = data

                        mMap.setOnInfoWindowClickListener { marker ->
                            val clickedData = marker.tag as ListStoryItem

                            val bundle = Bundle()
                            bundle.putString("name", clickedData.name)
                            bundle.putString("desc", clickedData.description)
                            bundle.putString("photo", clickedData.photoUrl)

                            val intent = Intent(this@MapsActivity, DetailActivity::class.java)
                            intent.putExtras(bundle)
                            startActivity(intent)
                        }

                    }
                    val bounds: LatLngBounds = boundsBuilder.build()
                    mMap.animateCamera(
                        CameraUpdateFactory.newLatLngBounds(
                            bounds,
                            resources.displayMetrics.widthPixels,
                            resources.displayMetrics.heightPixels,
                            300
                        )
                    )

                }
        }
    }
}