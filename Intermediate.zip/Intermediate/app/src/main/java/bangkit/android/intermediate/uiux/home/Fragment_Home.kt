package bangkit.android.intermediate.uiux.home

import DataStoreManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import bangkit.android.intermediate.Injection
import bangkit.android.intermediate.repo.StoryRepo
import bangkit.android.intermediate.adapter.LoadAdapter
import bangkit.android.intermediate.adapter.PagingAdapter
import bangkit.android.intermediate.api.Retrofit
import bangkit.android.intermediate.databinding.HomeFragmentBinding
import bangkit.android.intermediate.viewmodel.MyViewModel
import bangkit.android.intermediate.viewmodel.MyViewModelFactory
import bangkit.android.intermediate.uiux.maps.MapsActivity
import dataStore
import kotlinx.coroutines.launch


class Fragment_Home : Fragment() {
    private var _binding: HomeFragmentBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataStoreManager: DataStoreManager
    private lateinit var storyRepository: StoryRepo
    private lateinit var viewModel: MyViewModel
    private lateinit var recyclerView: RecyclerView
    private val adapter = PagingAdapter()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        dataStoreManager = DataStoreManager.getInstance(requireActivity().application.dataStore)
        storyRepository =
            StoryRepo(
                Retrofit.getApiService(dataStoreManager.getAuthTokenFlow().toString()),
                dataStoreManager
            )
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = HomeFragmentBinding.inflate(inflater, container, false)
        val view = binding.root

        val viewModelFactory = MyViewModelFactory(Injection.provideRepository(dataStoreManager), dataStoreManager)
        viewModel = ViewModelProvider(this, viewModelFactory)[MyViewModel::class.java]

        recyclerView = binding.listStory
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        fetchStories()
        binding.maps.setOnClickListener {
            startActivity(Intent(requireContext(), MapsActivity::class.java))
        }

        return view
    }

    private fun fetchStories() {

        lifecycleScope.launch {
            binding.listStory.adapter = adapter.withLoadStateFooter(
                footer = LoadAdapter {
                    adapter.retry()
                }
            )
        }

        viewModel.stories.observe(viewLifecycleOwner) {
            lifecycleScope.launch {
                try{
                    adapter.submitData(lifecycle, it)
                }catch (e: Exception) {
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onResume() {
        super.onResume()
    }
}