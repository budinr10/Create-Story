package bangkit.android.intermediate.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import bangkit.android.intermediate.databinding.CardstoryBinding
import bangkit.android.intermediate.feedback.ListStoryItem
import bangkit.android.intermediate.uiux.DetailActivity

import com.bumptech.glide.Glide

class ListStory(private val context: Context) : RecyclerView.Adapter<ListStory.ListStoryViewHolder>() {
    private var listStory: List<ListStoryItem> = emptyList()
    private var itemClickListener : OnItemClickListener? = null

    interface OnItemClickListener {
        fun onItemClick(item: ListStoryItem)
    }

    inner class ListStoryViewHolder(val binding: CardstoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListStoryViewHolder {
        val binding = CardstoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListStoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListStoryViewHolder, position: Int) {
        val item = listStory[position]
        val name = item.name
        val desc = item.description
        val photo = item.photoUrl
        holder.binding.apply {
            Glide.with(context)
                .load(photo)
                .into(postPhoto)

            descPhoto.text = desc
            namePhoto.text = name
            root.setOnClickListener {
                itemClickListener?.onItemClick(item)
                val bundle = Bundle()

                bundle.putString("name", name)
                bundle.putString("desc", desc)
                bundle.putString("photo", photo)

                val intent = Intent(context, DetailActivity::class.java)
                intent.putExtras(bundle)
                context.startActivity(intent)

            }
        }
    }

    override fun getItemCount(): Int {
        return listStory.size
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListStoryItem>() {
            override fun areItemsTheSame(oldItem: ListStoryItem, newItem: ListStoryItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: ListStoryItem, newItem: ListStoryItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}

