package bangkit.android.intermediate.feedback

import com.google.gson.annotations.SerializedName

data class FeedbackStory(

	@field:SerializedName("error")
	val error: Boolean? = null,

	@field:SerializedName("message")
	val message: String? = null
)
