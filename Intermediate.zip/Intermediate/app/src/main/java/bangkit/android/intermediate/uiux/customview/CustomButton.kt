package bangkit.android.intermediate.uiux.customview

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.cardview.widget.CardView
import android.widget.ProgressBar
import android.widget.TextView
import bangkit.android.intermediate.R

class CustomButton(context: Context, attrs: AttributeSet) : CardView(context, attrs) {
    private val progressBar: ProgressBar
    private val textView: TextView

    init {
        LayoutInflater.from(context).inflate(R.layout.custom_button, this, true)
        progressBar = findViewById(R.id.progressBar)
        textView = findViewById(R.id.textView)
    }

    fun startLoading() {
        progressBar.visibility = VISIBLE
        textView.visibility = INVISIBLE
    }

    fun stopLoading() {
        progressBar.visibility = INVISIBLE
        textView.visibility = VISIBLE
    }

    fun setButtonText(text: String) {
        textView.text = text
    }
}
