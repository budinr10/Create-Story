package bangkit.android.intermediate.repo

import DataStoreManager
import androidx.lifecycle.LiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import bangkit.android.intermediate.StoryPagingSource
import bangkit.android.intermediate.feedback.StoryResponse
import bangkit.android.intermediate.api.Api
import bangkit.android.intermediate.feedback.ListStoryItem
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class StoryRepo(private val api: Api, private val dataStore: DataStoreManager) {
    fun fetchStories(): LiveData<PagingData<ListStoryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 20
            ),
            pagingSourceFactory = {
                StoryPagingSource(api, dataStore)
            },
        ).liveData
    }

    suspend fun fetchStorieswithLocation(location: Int): StoryResponse =
        api.getStorieswithLocation( location)

    suspend fun uploadStory(
        authToken: String?,
        description: String,
        photoFile: File,
        lat: Float,
        lon: Float
    ): StoryResponse {
        val descriptionRequestBody = description.toRequestBody("text/plain".toMediaTypeOrNull())

        val photoPart = MultipartBody.Part.createFormData(
            "photo",
            photoFile.name,
            photoFile.asRequestBody("image/*".toMediaTypeOrNull())
        )

        return api.uploadStory(descriptionRequestBody, photoPart, lat, lon)
    }
}

