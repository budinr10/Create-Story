package bangkit.android.intermediate.viewmodel

import DataStoreManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import bangkit.android.intermediate.repo.StoryRepo

class MyViewModelFactory(private val storyRepo: StoryRepo, private val dataStoreManager: DataStoreManager) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MyViewModel::class.java)) {
            return MyViewModel(storyRepo, dataStoreManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
